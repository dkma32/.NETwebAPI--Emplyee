using Microsoft.EntityFrameworkCore;

namespace EmployeeAPI.Models
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options) { }

        public DbSet<Employee> Employees { get; set; }

        // Other DbSet properties, if needed

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Define any relationships, constraints, or configurations here
  
  
        modelBuilder.Entity<Employee>()
            .Property(e => e.Id)
            .ValueGeneratedOnAdd(); // This configures the 'Id' property to auto-generate values
    
           
           
           
           
           
           
           
            base.OnModelCreating(modelBuilder);
        }
    }
}
