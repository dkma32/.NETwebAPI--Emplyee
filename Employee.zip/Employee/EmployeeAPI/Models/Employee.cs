using System;
using System.ComponentModel.DataAnnotations;

public class Employee
{
    public int Id { get; set; }

    public string? FirstName { get; set; }
    public string? LastName { get; set; }

    [RegularExpression(@"^\+222\d{7}$")]
    public string? PhoneNumber { get; set; }
    public string? Department { get; set; }

    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public bool IsDeleted { get; set; }

}
